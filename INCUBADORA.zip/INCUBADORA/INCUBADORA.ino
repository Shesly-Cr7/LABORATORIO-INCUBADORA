#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <DHT.h>
#include "HX711.h"

// -------- OLED --------
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// -------- Pines --------
#define DHTPIN       41
#define DHTTYPE      DHT22

#define SDA_OLED     8
#define SCL_OLED     9

#define RELAY_K1     14   // Bombillo
#define RELAY_K2     15   // Ventilador

#define LED_BAJA     16
#define LED_OK       17
#define LED_ALTA     18

#define HX_DT        11
#define HX_SCK       12

#define BOTON_TARA   10

DHT dht(DHTPIN, DHTTYPE);
HX711 balanza;

// -------- Relés --------
#define RELAY_ON  LOW
#define RELAY_OFF HIGH

// -------- Umbrales --------
float T_OFF = 37.5;
float T_ON  = 36.0;

// -------- Peso --------
float peso = 0.0;
float pesoFiltrado = 0.0;
float factor_calibracion = 286.0;

// -------- Variables --------
float temperatura = 0.0;
float humedad = 0.0;

// -------- Control --------
bool sistemaCalentando = true;

// -------- Botón --------
unsigned long lastButtonTime = 0;
const unsigned long debounceTime = 300;

// -------- Tiempo --------
unsigned long lastRead = 0;
unsigned long lastOLED = 0;

// ================= TARA =================
void hacerTara() {

  display.clearDisplay();
  display.setCursor(0, 18);
  display.println("Tarando...");
  display.setCursor(0, 34);
  display.println("Quite el peso");
  display.display();

  delay(700);

  balanza.tare(10);
  pesoFiltrado = 0;
  peso = 0;

  display.clearDisplay();
  display.setCursor(0, 26);
  display.println("Tara realizada");
  display.display();

  delay(700);
}

// ================= BOTÓN =================
void revisarBotonTara() {
  if (digitalRead(BOTON_TARA) == LOW) {
    if (millis() - lastButtonTime > debounceTime) {
      lastButtonTime = millis();
      hacerTara();
    }
  }
}

// ================= DHT =================
void leerDHT() {
  float t = dht.readTemperature();
  float h = dht.readHumidity();

  if (!isnan(t)) temperatura = t;
  if (!isnan(h)) humedad = h;
}

// ================= PESO =================
void leerPeso() {
  if (balanza.is_ready()) {
    float lectura = balanza.get_units(5);

    pesoFiltrado = 0.7 * pesoFiltrado + 0.3 * lectura;

    if (pesoFiltrado > -2.0 && pesoFiltrado < 2.0) {
      pesoFiltrado = 0.0;
    }

    peso = pesoFiltrado;
  }
}

// ================= LEDS =================
void actualizarLEDs() {
  if (temperatura < T_ON) {
    digitalWrite(LED_BAJA, HIGH);
    digitalWrite(LED_OK, LOW);
    digitalWrite(LED_ALTA, LOW);
  }
  else if (temperatura >= T_OFF) {
    digitalWrite(LED_BAJA, LOW);
    digitalWrite(LED_OK, LOW);
    digitalWrite(LED_ALTA, HIGH);
  }
  else {
    digitalWrite(LED_BAJA, LOW);
    digitalWrite(LED_OK, HIGH);
    digitalWrite(LED_ALTA, LOW);
  }
}

// ================= CONTROL =================
void controlarSistema() {

  if (sistemaCalentando) {
    digitalWrite(RELAY_K1, RELAY_ON);

    // 🔥 Ventilador SOLO cuando T >= 37.5
    if (temperatura >= T_OFF) {
      digitalWrite(RELAY_K2, RELAY_ON);
    } else {
      digitalWrite(RELAY_K2, RELAY_OFF);
    }

    if (temperatura >= T_OFF) {
      digitalWrite(RELAY_K1, RELAY_OFF);
      sistemaCalentando = false;
    }
  }
  else {

    digitalWrite(RELAY_K1, RELAY_OFF);

    // 🔥 Ventilador SOLO cuando T >= 37.5
    if (temperatura >= T_OFF) {
      digitalWrite(RELAY_K2, RELAY_ON);
    } else {
      digitalWrite(RELAY_K2, RELAY_OFF);
    }

    if (temperatura <= T_ON) {
      sistemaCalentando = true;
    }
  }
}

// ================= OLED =================
void mostrarOLED() {
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(1);

  display.setCursor(0, 0);
  display.println("Incubadora");

  display.setCursor(0, 12);
  display.print("Temp: ");
  display.print(temperatura, 1);
  display.println(" C");

  display.setCursor(0, 24);
  display.print("Hum : ");
  display.print(humedad, 1);
  display.println(" %");

  display.setCursor(0, 36);
  display.print("Peso: ");
  display.print(peso, 1);
  display.println(" g");

  display.display();
}

// ================= SETUP =================
void setup() {
  Serial.begin(115200);

  pinMode(RELAY_K1, OUTPUT);
  pinMode(RELAY_K2, OUTPUT);

  pinMode(LED_BAJA, OUTPUT);
  pinMode(LED_OK, OUTPUT);
  pinMode(LED_ALTA, OUTPUT);

  pinMode(BOTON_TARA, INPUT_PULLUP);

  dht.begin();

  Wire.begin(SDA_OLED, SCL_OLED);

  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("OLED no detectada");
    while (true);
  }

  // HX711
  balanza.begin(HX_DT, HX_SCK);
  balanza.set_scale(factor_calibracion);

  delay(1500);
  balanza.tare(10);

  display.clearDisplay();
  display.setCursor(0, 20);
  display.println("Sistema listo");
  display.display();

  delay(1000);
}

// ================= LOOP =================
void loop() {

  unsigned long ahora = millis();

  revisarBotonTara();

  if (ahora - lastRead >= 2000) {
    lastRead = ahora;
    leerDHT();
    controlarSistema();
    actualizarLEDs();
  }

  leerPeso();
  controlarSistema();

  if (ahora - lastOLED >= 200) {
    lastOLED = ahora;
    mostrarOLED();
  }
}